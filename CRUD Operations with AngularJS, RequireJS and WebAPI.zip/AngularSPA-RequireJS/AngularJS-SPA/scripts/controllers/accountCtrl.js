﻿define(['app'], function (app) {
    app.controller("aboutCtrl", function ($scope) {
        $scope.Message = "About Us";        
    });
});